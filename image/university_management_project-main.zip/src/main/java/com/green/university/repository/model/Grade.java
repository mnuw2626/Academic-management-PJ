package com.green.university.repository.model;

import lombok.Data;

@Data
public class Grade {

	private String grade;
	private Integer gradeValue;
}

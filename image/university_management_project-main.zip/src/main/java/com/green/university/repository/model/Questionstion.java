package com.green.university.repository.model;

import lombok.Data;

@Data
public class Questionstion {
	private Integer id;
	private String question1;
	private String question2;
	private String question3;
	private String question4;
	private String question5;
	private String question6;
	private String question7;
	private String sug_content;
}

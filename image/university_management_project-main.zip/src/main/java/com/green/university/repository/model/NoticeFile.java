package com.green.university.repository.model;

import lombok.Data;

@Data
public class NoticeFile {

	private Integer noticeId;
	private String originFilename;
	private String uuidFilename;
}

package com.green.university.dto.response;

import lombok.Data;

@Data
public class QuestionDto {
	
	private String question1;
	private String question2;
	private String question3;
	private String question4;
	private String question5;
	private String question6;
	private String question7;
	private String sugContent;
}

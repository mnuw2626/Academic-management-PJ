package com.green.university.repository.model;

import lombok.Data;

@Data
public class Room {

	private String id;
	private Integer collegeId;
	
}

package com.green.university.repository.model;

import lombok.Data;

@Data
public class CollTuit {

	private Integer collegeId;
	private Integer amount;
}

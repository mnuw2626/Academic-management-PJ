package com.green.university.dto.response;

import lombok.Data;

@Data
public class StuSubSumGradesDto {

	private Integer studentId;
	private Integer sumGrades;
	
}

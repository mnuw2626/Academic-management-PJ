package com.green.university.dto;

import lombok.Data;

@Data
public class GradecheckFormDto {
	private Integer subYear;
	private Integer semeter;
	private String type;
}

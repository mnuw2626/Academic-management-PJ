package com.green.university.dto;

import lombok.Data;
/**
 * 
 * @author 박성희
 *
 */
@Data
public class SyllaBusFormDto {
	
	private Integer subjectId;
	private String overview;
	private String objective;
	private String textbook;
	private String program;
	
}

package com.green.university.dto;

public class ThisGradeDto {

}
